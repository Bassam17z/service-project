// Package openai interfaces directly with the openai APIs.
package openai
