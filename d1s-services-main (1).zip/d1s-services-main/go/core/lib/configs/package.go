// Package configs retrieves config information
package configs
