// Package gcp interfaces with Google GCP services
package gcp
