// Package chat manages ChatGPT model
package chat
