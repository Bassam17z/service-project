// Package chatpad manages ChatGPT model
package chatpad
