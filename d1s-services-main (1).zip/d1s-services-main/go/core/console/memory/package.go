// Package memory is ingest console functionality.
package memory
