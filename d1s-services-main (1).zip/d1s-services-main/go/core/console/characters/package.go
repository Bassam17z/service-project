// Package characters contains character console commands.
package characters
