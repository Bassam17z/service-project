// Package llm manages llm console app functions.
package llm
