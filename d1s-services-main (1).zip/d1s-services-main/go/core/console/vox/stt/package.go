// Package stt is speech-to-text
package stt
