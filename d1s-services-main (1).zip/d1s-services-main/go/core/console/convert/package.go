// Package convert manages conversions
package convert
